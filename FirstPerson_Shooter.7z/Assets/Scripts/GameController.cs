﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameController : MonoBehaviour {
	public Text gameOverText;
	public Text restartText;
	public Text Intro;
	public Text Health;

	public PlayerController playerController;

	private bool gameOver;

	void Start () {

		//Setting the Framerate
		Application.targetFrameRate = 60;


		//Setting GameOver Logic
		gameOver = false;
		gameOverText.text = "";
		restartText.text = "";
	
	}
	void Update () {

		//Game Over and Restarting
		if (playerController.Health <= 0){
			gameOver = true;
			playerController.movementAllowed = false;
			gameOverText.text = "Game Over!";
			restartText.text = "Press 'R' to Restart";
		}
		if (gameOver){
			if(Input.GetKeyDown (KeyCode.R)){
				playerController.movementAllowed = true;
				gameOver = false;
				playerController.Spawning();
			}

		}else{
			gameOverText.text = "";
			restartText.text = "";
		}

		if(Input.GetButtonDown ("Fire1")){
			Intro.text = "";
		}

		Health.text = playerController.Health + "/10";
	}
}
