﻿using UnityEngine;
using System.Collections;

public class BulletController : MonoBehaviour {

	void OnTriggerEnter(Collider other){

		if(this.CompareTag ("EnemyBullet")){
			if(other.gameObject.CompareTag ("Enemy")){
			}else{
				Destroy (gameObject);
			}
		}

		if (this.CompareTag ("PlayerBullet")) {
			if (other.gameObject.CompareTag ("Enemy")) {
				Destroy (other.gameObject);
				Destroy (gameObject);
			}
			if (other.gameObject.CompareTag ("Player")){
			}else{
				Destroy (gameObject);
			}
		}
	}
}
