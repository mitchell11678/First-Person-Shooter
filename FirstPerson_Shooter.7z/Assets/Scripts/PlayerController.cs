﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

[RequireComponent (typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
	public float defaultSpeed;
	public float sprintSpeed;
	public float mouseSpeed;
	public float upDownDistance;
	public float jumpSpeed;
	public float Health;
	public bool movementAllowed = true;
	public Text winningText;

	Vector3 spawn = new Vector3 (145.0f, 2.1f, 122.24f);

	Quaternion spawnRotation = Quaternion.Euler (0, 270, 0);

	float rotationUD = 0.0f;
	float verticalVelocity = 0.0f;
	float moveSpeed;


	CharacterController cc;

	void Start ()
	{

		moveSpeed = defaultSpeed;

		Cursor.lockState = CursorLockMode.Locked;
		Cursor.visible = false;

		cc = GetComponent<CharacterController> ();
	}

	void Update ()
	{
		
		//Rotation
		float rotationLR = Input.GetAxis ("Mouse X");
		rotationUD = Input.GetAxis ("Mouse Y");
		float currentUD = Camera.main.transform.rotation.eulerAngles.x;
		float desiredUD = currentUD - rotationUD * mouseSpeed;

		rotationUD = Mathf.Clamp (rotationUD, -upDownDistance, upDownDistance);

		Camera.main.transform.localRotation = Quaternion.Euler (desiredUD, 0.0f, 0.0f);

		transform.Rotate (0.0f, rotationLR * mouseSpeed, 0.0f);

		//Movement
		float forward = 0.0f;
		float side = 0.0f;

		if (cc.isGrounded) {
		} else
			verticalVelocity += Physics.gravity.y * Time.deltaTime;

		if (movementAllowed) {
			
			forward = Input.GetAxis ("Vertical") * moveSpeed;
			side = Input.GetAxis ("Horizontal") * moveSpeed;

			if (Input.GetKey (KeyCode.LeftShift)) {
				moveSpeed = sprintSpeed;
			} else
				moveSpeed = defaultSpeed;

			if (cc.isGrounded && Input.GetButtonDown ("Jump")) {
				Debug.Log ("Grounded");
				verticalVelocity = jumpSpeed;
			}
		}

			Vector3 motion = new Vector3 (side, verticalVelocity, forward);

			motion = transform.rotation * motion;

			cc.Move (motion * Time.deltaTime);
	}

	//Spawning and Death
	void OnTriggerEnter (Collider other)
	{
		if (other.CompareTag ("Spawn")) {
			spawn = other.transform.position;
			spawnRotation = other.transform.rotation;
		} else if (other.CompareTag ("EnemyBullet")) {
			Health--;
		} else if (other.CompareTag ("Hazard")) {
			Health -= 100;
		}

		//Win Text
		if (other.gameObject.name.Equals ("Spawn6") || other.gameObject.name.Equals ("Spawn7")){
			winningText.text = "Thank you for playing through my first game in Unity! I hope you enjoyed your experience and know that I will definitely be making more projects in the future!";
		}
	}

	public void Spawning ()
	{
		this.transform.position = spawn;
		this.transform.rotation = spawnRotation;
		Health = 10;
	}
}
