﻿using UnityEngine;
using System.Collections;

public class ShooterController : MonoBehaviour {

	public float bulletSpeed;

	public GameObject bullet_prefab;

	private Rigidbody rb;

	void Update () {
		if(Input.GetButtonDown("Fire1")){
			Camera cam = Camera.main;
			GameObject Bullet = (GameObject)Instantiate (bullet_prefab, cam.transform.position, transform.rotation);
			rb = Bullet.GetComponent<Rigidbody> ();
			rb.AddForce (cam.transform.forward * bulletSpeed, ForceMode.Impulse);
		}
	}
}
