﻿using UnityEngine;
using System.Collections;

public class SpawnerController : MonoBehaviour
{
	GameObject[] Enemies;

	void OnTriggerEnter (Collider other)
	{

		switch (other.gameObject.name) {
		case "Spawn0":
			Debug.Log (other.gameObject.name);
			Activating ("Enemy0");
			break;
		case "Spawn1":
			System.Array.Clear (Enemies, 0, Enemies.Length);
			Activating ("Enemy1");
			break;
		case "Spawn2":
			System.Array.Clear (Enemies, 0, Enemies.Length);
			Activating ("Enemy2");
			break;
		case "Spawn3":
			System.Array.Clear (Enemies, 0, Enemies.Length);
			Activating ("Enemy3");
			break;
		case "Spawn4":
			System.Array.Clear (Enemies, 0, Enemies.Length);
			Activating ("Enemy4");
			break;
		case "Spawn5":
			System.Array.Clear (Enemies, 0, Enemies.Length);
			Activating ("Enemy5");
			break;
		}

	}

	void Activating(string Room){
		Enemies = GameObject.FindGameObjectsWithTag (Room);

		for(int i = 0;i<Enemies.Length; i++){
			for(int j = 0;j<Enemies[i].transform.childCount;j++){
				Enemies [i].transform.GetChild (j).gameObject.SetActive (true);
			}
		}
	}

	/*public static GameObject FindObject(this GameObject parent, string name){
		Transform[] trs = parent.GetComponentsInChildren (typeof(Transform), true);
		foreach(Transform t in trs){
			if(t.name == name){
				return t.gameObject;
			}
		}
		return null;
	}*/
}
