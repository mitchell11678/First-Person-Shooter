﻿using UnityEngine;
using System.Collections;

public class PlatformController : MonoBehaviour {

	public float moveSpeed;

	float variable = 1;

	int count;

	Vector3 position = new Vector3();

	void Update () {

		while (true) {
			switch (this.tag) {
			case "PlatformX":
				this.transform.Translate (this.position + Vector3.left * moveSpeed * Time.deltaTime * variable);
				Debug.Log (count++);
				break;
			case "PlatformZ":
				this.transform.Translate (this.position + Vector3.forward * moveSpeed * Time.deltaTime * variable);
				break;
			case "Column":
				this.transform.Translate (this.position + Vector3.down * moveSpeed * Time.deltaTime * variable);
				break;
			}
		}
	
	}

	void OnTriggerEnter(Collider other){
		if(other.CompareTag ("Boundary")){
			variable *= -1;
		}
	}
}
