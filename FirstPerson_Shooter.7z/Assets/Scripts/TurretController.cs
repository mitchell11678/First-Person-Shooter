﻿using UnityEngine;
using System.Collections;

public class TurretController : MonoBehaviour
{
	
	public float bulletSpeed;
	public float shotInterval;

	public GameObject bullet_prefab;

	public Transform player;

	Rigidbody rb;
	bool firstShot = false;
	bool canFire = false;
	float shotTime;

	Vector3 firingPosition = new Vector3();

	void Start(){

		firingPosition = this.transform.position;
		firingPosition.y += 4.5f;

	}

	void Update ()
	{
		//Shooting
		if (firstShot) {
			shotTime += Time.deltaTime;
			if (shotTime >= shotInterval)
				canFire = true;
			if (canFire) {
				GameObject Bullet = (GameObject)Instantiate (bullet_prefab, firingPosition, transform.rotation);
				rb = Bullet.GetComponent<Rigidbody> ();
				rb.AddForce (this.transform.forward * bulletSpeed, ForceMode.Impulse);
				shotTime = 0.0f;
				canFire = false;
			}
			} else {
			shotTime = Random.Range (0.0f, shotInterval);
			firstShot = true;
		}

		//Turret Rotation
		var playerPosition = player.position;
		playerPosition.y = transform.position.y;

		if (player)
			transform.LookAt (playerPosition);
	}
}
