# First-Person-Shooter
This is a simple first person shooter in which the player is in a level with turrets that fire at them, once you reach the end you win.

Created by Mitchell Brown in Unity Personal

Currently stil a W.I.P only the level is properly textured, there is currently no shooting or damage to be taken, none of the 
environmental hazards are in yet either. The chcaracter jump height is much higher than normal just for ease of going around the 
level to look at it.

